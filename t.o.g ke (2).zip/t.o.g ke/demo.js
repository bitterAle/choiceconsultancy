const words = ["HELP OTHERS", "HELP US", "HELP OTHERS"]; // An array of words to be used for replacement
const wordDiv = document.getElementById("word"); // Get the div element
let index = 0; // Initialize the index variable

// Set an interval to update the word in the div element every 2 seconds
setInterval(() => {
    wordDiv.textContent = words[index]; // Set the content of the div element to the current word in the array
    index = (index + 1) % words.length; // Increment the index variable and reset it to 0 when it reaches the end of the array
}, 4000);

// Variables
let prev = document.querySelector('.prev');
let next = document.querySelector('.next');
let imgs = document.querySelectorAll('.carousel-img');
let dots = document.querySelectorAll('.dot');
let captions = document.querySelectorAll('.carousel-caption')
let totalImgs = imgs.length;
let imgPosition = 0;

// Event Listeners
next.addEventListener('click', nextImg);
prev.addEventListener('click', prevImg);

// Update Position
function updatePosition() {
    //   Images
    for (let img of imgs) {
        img.classList.remove('visible');
        img.classList.add('hidden');
    }
    imgs[imgPosition].classList.remove('hidden');
    imgs[imgPosition].classList.add('visible')
        //   Dots
    for (let dot of dots) {
        dot.className = dot.className.replace(" active", "");
    }
    dots[imgPosition].classList.add('active');
    //   Captions
    for (let caption of captions) {
        caption.classList.remove('visible');
        caption.classList.add('hidden');
    }
    captions[imgPosition].classList.remove('hidden');
    captions[imgPosition].classList.add('visible')
}

// Next Img
function nextImg() {
    if (imgPosition === totalImgs - 1) {
        imgPosition = 0;
    } else {
        imgPosition++;
    }
    updatePosition();
}
//Previous Image
function prevImg() {
    if (imgPosition === 0) {
        imgPosition = totalImgs - 1;
    } else {
        imgPosition--;
    }
    updatePosition();
}

// Dot Position
dots.forEach((dot, dotPosition) => {
    dot.addEventListener("click", () => {
        imgPosition = dotPosition
        updatePosition(dotPosition)
    })
})



const swiper = new Swiper('.swiper', {
    // Optional parameters
    direction: 'horizontal',
    loop: true,

    // If we need pagination
    pagination: {
        el: '.swiper-pagination',
    },

    // Navigation arrows
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },

    // And if we need scrollbar
    scrollbar: {
        el: '.swiper-scrollbar',
    },
});
new Glide('.glide', {
    type: 'carousel',
    startAt: 0,
    perView: 3
})

gsap.registerPlugin(ScrollTrigger);
gsap.from(".event-each", { duration: 3, opacity: 0, scale: 0.3, x: 300, stagger: 0.25, ease: 'back' });
gsap.from(".hero", {
    duration: 2,
    opacity: 0,
    y: 200,
    stagger: 0.5,
    ease: "slow"
});
gsap.from(".eachnumber", {
    ScrollTrigger: ".eachnumber",
    duration: 5,
    x: 300,
    stagger: 0.25
});
gsap.to(".ball", {
    duration: 5,
    rotate: 360
})